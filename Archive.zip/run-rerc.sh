#!/bin/sh
# CD
java -cp ./rerc.jar:./jsoup.jar org.theglump.rerc.RERC
